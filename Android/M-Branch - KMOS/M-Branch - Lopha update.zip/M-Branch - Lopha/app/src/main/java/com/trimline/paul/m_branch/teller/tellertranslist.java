package com.trimline.paul.m_branch.teller;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class tellertranslist extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tellertranslist);
    }
}