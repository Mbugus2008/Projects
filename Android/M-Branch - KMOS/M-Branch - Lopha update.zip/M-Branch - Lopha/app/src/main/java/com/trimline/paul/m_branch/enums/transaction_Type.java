package com.trimline.paul.m_branch.enums;

public enum transaction_Type {

    /// <remarks/>
    Issue_To_Teller,

    /// <remarks/>
    Return_To_Treasury,

    /// <remarks/>
    Issue_From_Bank,

    /// <remarks/>
    Return_To_Bank,

    /// <remarks/>
    Inter_Teller_Transfers,

    /// <remarks/>
    Branch_Manager_Transactions,

    /// <remarks/>
    End_of_Day_Return_Cash,
}
