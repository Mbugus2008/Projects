package com.trimline.paul.lopha.enums;

public enum received {

    /// <remarks/>
    No,

    /// <remarks/>
    Yes,
}
