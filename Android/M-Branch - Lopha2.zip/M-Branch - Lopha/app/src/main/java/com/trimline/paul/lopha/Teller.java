package com.trimline.paul.lopha;

import com.trimline.paul.lopha.enums.issued;
import com.trimline.paul.lopha.enums.received;
import com.trimline.paul.lopha.enums.teller_status;
import com.trimline.paul.lopha.enums.transaction_Type;

import java.sql.Time;
import java.util.Date;

public class Teller {
    public String Key ;
    public String No ;
    public Date Transaction_Date ;
    public transaction_Type Transaction_Type ;
    public String From_Account ;
    public String To_Account ;
    public String Description ;
    public double Amount ;
    public boolean Posted ;
    public Time Transaction_Time ;
    public double Coinage_Amount ;
    public String Currency_Code ;
    public issued Issued ;
    public Date Date_Issued ;
    public Date Time_Issued ;
    public Date Date_Received ;
    public Time Time_Received ;
    public String Issued_By ;
    public String Received_By ;
    public received Received ;
    public String Request_No ;
    public String Bank_No ;
    public double Denomination_Total ;
    public String External_Document_No ;
    public String Cheque_No ;
    public String Transacting_Branch ;
    public boolean Approved ;

    public String Last_Transaction ;
    public double Total_Cash_on_Treasury_Coinage ;
    public double Till_Treasury_Balance ;
    public double Excess_Shortage_Amount ;
    public String From_Account_Name ;
    public String To_Account_Name ;
    public double Actual_Cash_At_Hand ;
    public String Branch ;
    public String Branch_Code ;
    public teller_status Status ;
    public String Description_Excess_Shortage ;
    public String Remarks ;
    public double Treasury_Balance ;

}


