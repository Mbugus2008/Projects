package com.trimline.paul.lopha.enums;

public enum teller_status {

    /// <remarks/>
    Open,

    /// <remarks/>
    Pending_Approval,

    /// <remarks/>
    Approved,

    /// <remarks/>
    Rejected,
}
