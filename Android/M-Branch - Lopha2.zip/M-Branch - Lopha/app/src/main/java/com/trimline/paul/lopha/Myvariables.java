package com.trimline.paul.lopha;

import android.app.Application;

import java.util.ArrayList;

public class Myvariables extends Application  {

    public static agent CurrentAgent;
    public static ArrayList<String> vehs;

}

