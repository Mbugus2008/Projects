package com.trimline.paul.lopha;



public class tsummary {
public String Type;
public double Amount;
public String Date;
}
