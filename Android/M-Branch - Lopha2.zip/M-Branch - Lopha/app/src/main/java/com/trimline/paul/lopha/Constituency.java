package com.trimline.paul.lopha;

/**
 * Created by Paul on 15-Dec-16.
 */

public class Constituency {

    public String  No ;
    public String Decription;
    @Override
    public String toString() {
        return this.No;
    }
}
