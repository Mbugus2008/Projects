package com.trimline.paul.lopha;

public class Results<T> {

    public int Code  = 0;
    public String Desc ;
    public T Contents ;
}
