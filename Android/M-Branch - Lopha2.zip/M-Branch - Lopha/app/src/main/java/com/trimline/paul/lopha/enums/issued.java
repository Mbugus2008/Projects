package com.trimline.paul.lopha.enums;

public enum issued {

    /// <remarks/>
    No,

    /// <remarks/>
    Yes,

    /// <remarks/>
    N_A,
}
