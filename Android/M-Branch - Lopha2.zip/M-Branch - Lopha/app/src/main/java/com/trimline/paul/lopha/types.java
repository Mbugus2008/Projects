package com.trimline.paul.lopha;
/**
 * Created by Paulo on 3/8/2017.
 */

public class types {
  public String  Code;
  public String  Name;
   public boolean   Active;
  public boolean Attach_to_vehicle;
  public int Order;
  @Override
  public String toString() {
    return this.Name;
  }
}
