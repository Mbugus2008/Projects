# Flutter Invoice Manager - Setup Guide

## Quick Start for Your Dynamics 365 Test Environment

### 1. Extract and Setup
```bash
# Extract the project
tar -xzf invoice_manager_project.tar.gz
cd invoice_manager

# Install dependencies
flutter pub get
```

### 2. Configure Your D365 Environment

#### In Azure Portal:
1. **App Registration**:
   - Go to Azure AD → App registrations → New registration
   - Name: "Invoice Manager Mobile"
   - Redirect URI: `com.invoiceapp.invoicemanager://auth`
   - Copy Client ID and Tenant ID

2. **API Permissions**:
   - Add "Dynamics CRM" → "user_impersonation"
   - Add "Microsoft Graph" → "User.Read"
   - Grant admin consent

#### In the App:
1. Run `flutter run`
2. Navigate to configuration screen
3. Enter your details:
   - Organization URL: `https://[yourorg].crm.dynamics.com`
   - Client ID: From Azure AD
   - Tenant ID: From Azure AD

### 3. Test Connection
- Tap "Save Configuration"
- Complete Microsoft authentication
- Access dashboard with D365 data

### 4. Development Next Steps
The app is ready for:
- Customer management with live D365 data
- Invoice creation and management
- Payment tracking
- Document generation

### Files Included:
- Complete Flutter project structure
- All source code and assets
- Dynamics 365 integration services
- UI wireframes and design system
- Configuration and setup files

**Ready to connect to your D365 test environment!** 🚀

