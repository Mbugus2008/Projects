﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;

namespace S_Mobile
{
    public partial class Smobile : ServiceBase
    {
        public Smobile()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            Clients.Start();

        }

        protected override void OnStop()
        {
            Clients.close = true;
        }
    }
}
