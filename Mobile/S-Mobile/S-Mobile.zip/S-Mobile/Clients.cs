﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Mobile;
using Mpesa;

namespace S_Mobile
{
    class Clients
    {
        public Client client;
        public static Boolean close = false;
        public const string regmessage = "Your Mobile banking registration is successfully your start pin is {0}, Please dial *483*68#";
        public MobileEntities db = new MobileEntities();
        public ClientService.Client service = new ClientService.Client();
        public Paybill.Soap paybill = new Paybill.Soap();
        public static Logging.settings s = new Logging.settings();
        public bool sendsms(string phone, string text)
        {
            Sendsms.send.sms s = new Sendsms.send.sms();
            s.Sourceid = DateTime.Now.Ticks.ToString();
            phone = phone.Replace(" ", "");
            s.phone = "+254" + phone.Substring(phone.Length - 9);
            s.text = text;
            s.client = client.Sms_Outlet;
            Sendsms.Sms.Sendsms(ref s);
            if (s.results.code == 0)
            {
                client.Sms_Balance = s.balance;
                return true;
            }
            else
                return true;
        }

        public int GenerateRandomNo()
        {
            int _min = 1000;
            int _max = 9999;
            Random _rdm = new Random();
            return _rdm.Next(_min, _max);
        }


        public static void Start()
        {
            s = s.loadsettings(AppDomain.CurrentDomain.BaseDirectory + @"\Settings.xml");
            Logging.Logging.LogEntryOnFile("Service Started");
            Thread _threadbulk = new Thread(process);
            _threadbulk.IsBackground = false; // true;
            _threadbulk.Priority = ThreadPriority.Normal;
            _threadbulk.SetApartmentState(ApartmentState.STA);
            _threadbulk.Start();
        }

        public static void process()
        {
            Bandari h = new Bandari();
            Homabay homa = new Homabay();
            while (close == false)
            {
                h.registrations();
                sendscheduledsms();
                smsbalancenotify();
                Thread.Sleep(10000);
            }
        }
        public static void sendscheduledsms()
        {
            try
            {
                using (var db = new MobileEntities())
                {
                    var sms = db.BulkSms.Where(o => o.Scheduled == true && o.Status == 0 && o.Scheduled_Time < DateTime.Now);
                    Logging.Logging.LogEntryOnFile(string.Format("Scheduled sms count {0}", sms.Count()));
                    foreach (var sm in sms.ToList())
                    {
                        Sendsms.send.sms s = new Sendsms.send.sms();
                        s.Sourceid = DateTime.Now.Ticks.ToString();
                        s.phone = sm.Phone;
                        s.text = sm.Message;
                        s.client = sm.Client;
                        s.Smsclient = sm.Client;
                        Sendsms.Sms.Sendsmsonly(ref s);
                        Logging.Logging.LogEntryOnFile(string.Format("Results: {0}", s.results.code));
                        if (s.results.code == 0)
                            sm.Status = 1;
                        else
                        {
                            sm.Status = 1;
                            sm.Comments = s.results.Description;
                        }
                        db.SaveChanges();
                    }
                }
            }
            catch (Exception ex)
            {
                Logging.Logging.ReportError(ex);

            }
        }
        public static void smsbalancenotify()
        {
            try
            {
                using (var db = new MobileEntities())
                {
                    var clients = db.Clients.Where(o => o.Notify_low_sms == true);
                    foreach (var client in clients)
                    {
                        client.Sms_Balance = smsbalance(client.Client_Code);
                        if (client.Sms_Balance < client.Sms_reorder_level)
                        {
                            email email = new email();
                            email.To_address = client.Email;
                            email.CC = client.email_cc;
                            email.body = string.Format("Hi {2} This is to inform you that your sms credit level is below thresh hold \n\n" +
                                "Current Balance = {0}\n" +
                                "Threshold = {1}\n"
                                , client.Sms_Balance, client.Sms_reorder_level, client.Client_Name);
                            email.subject = "Courtesy Balance Notification";

                            var nmin = db.Notifications.OrderByDescending(i => i.Id).Where(o => o.Client == client.Client_Code).FirstOrDefault();

                            if (nmin != null)
                            {
                                switch ((notifyinterval)client.Interval_Type)
                                {
                                    case notifyinterval.Day:
                                        if ((DateTime.Today - nmin.Date_Time.Value).TotalDays > 0)
                                        {
                                            email.send(email);
                                            Notification n = new Notification();
                                            n.Client = client.Client_Code;
                                            n.Date_Time = DateTime.Now;
                                            db.Notifications.Add(n);
                                        }
                                        break;
                                }

                            }
                            else
                            {
                                email.send(email);
                                Notification n = new Notification();
                                n.Client = client.Client_Code;
                                n.Date_Time = DateTime.Now;
                                db.Notifications.Add(n);
                            }


                        }
                    }
                    db.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                Logging.Logging.ReportError(ex);

            }
        }
        public static int smsbalance(string client)
        {
            int bal = 0;
            try
            {

                using (var db = new MobileEntities())
                {
                    bal = (int)db.BulkSms.Where(o => o.Client == client).Sum(o => o.Value);
                }
            }
            catch (Exception ex)
            {
                Logging.Logging.ReportError(ex);

            }
            return bal;
        }
        
    }
    enum notifyinterval
    {
        Min = 1, Hour = 2, Day = 3
    }
    public class email
    {
        public string subject;
        public string body;
        public string To_address;
        public string CC;
        public void send(email e)
        {
            var fromAddress = new MailAddress("smsnotificatiosn@gmail.com", "");
            var toAddress = new MailAddress(e.To_address);
            string fromPassword = "Rahabgathoni1";
            string subject = e.subject;
            string body = e.body;

            var smtp = new SmtpClient
            {
                Host = "smtp.gmail.com",
                Port = 587,
                EnableSsl = true,
                DeliveryMethod = SmtpDeliveryMethod.Network,
                UseDefaultCredentials = false,
                Credentials = new NetworkCredential(fromAddress.Address, fromPassword)
            };
            using (var message = new MailMessage())
            {
                message.From = fromAddress;
                message.CC.Add(e.CC);
                message.To.Add(toAddress);
                message.Subject = subject;
                message.Body = body;

                smtp.Send(message);
            }


        }
    }
}
