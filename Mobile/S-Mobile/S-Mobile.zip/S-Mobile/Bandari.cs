﻿using Mobile;
using System;
using System.Linq;

namespace S_Mobile
{
    class Bandari : Clients
    {
        const string c = "01";
        Mpesa.Mpesa mpesa = null;
        public Bandari()
        {
            try
            {
                client = db.Clients.FirstOrDefault(o => o.Client_Code == c);
                service.Url = client.Url;
                Mpesa.Mpesa.customer cust = new Mpesa.Mpesa.customer();
                cust.customer_key = client.Customer_Key;
                cust.customer_secret = client.Customer_Secret;
                mpesa= new Mpesa.Mpesa(cust);

                Logging.Logging.LogEntryOnFile(service.Url);
            }
            catch (Exception ex)
            {
                Logging.Logging.ReportError(ex);
            }
        }

        public void registrations()
        {
            try
            {
                var r = service.Registration();
                Logging.Logging.LogEntryOnFile(string.Format("{0} Registrations {1}", client.Client_Name, r.Count()));
                foreach (ClientService.Applications a in r)
                {
                    var c = db.Customers.FirstOrDefault(o => o.Telephone == a.telephoneField && o.Client == client.Client_Code);
                    if (c == null)
                    {
                        c = new Customer();
                        c.Telephone = a.telephoneField;
                        c.Client = client.Client_Code;
                        db.Customers.Add(c);
                    }
                    c.Name = a.account_NameField;
                    c.Language = "EN";
                    c.PinChanged = false;
                    c.Active = true;
                    var l = db.Logins.FirstOrDefault(o => o.Telephone == a.telephoneField);
                    if (l == null)
                    {
                        l = new Login();
                        l.Telephone = a.telephoneField;
                        db.Logins.Add(l);
                    }
                    l.Start_Pin = GenerateRandomNo().ToString();
                    l.PIN_Encrypted = l.Start_Pin;

                    db.SaveChanges();
                    c.Registration_Sms_sent = sendsms(c.Telephone, string.Format(regmessage, l.Start_Pin));
                    db.SaveChanges();
                }

            }
            catch (Exception ex) { Logging.Logging.ReportError(ex); }
        }
        public void Deposits()
        {
            using (var db = new MobileEntities())
            {
                var deposits = db.Transactions.Where(o => (Transtype)o.Transaction_Type == Transtype.Deposit && o.Client == c && o.Status == (int)Status.Completed && o.Mpesa_Status == (int)Status.Pending);

                foreach (var d in deposits.ToList())
                {
                    try
                    {
                        Mpesa.Mpesa.stkpush stkpush = new Mpesa.Mpesa.stkpush();
                        stkpush.BusinessShortCode = client.Paybill_No;
                        stkpush.Amount = (double)d.Amount;
                        stkpush.PartyA = d.MSISDN;
                        stkpush.PartyB = stkpush.BusinessShortCode;
                        stkpush.PhoneNumber = d.MSISDN;
                        stkpush.CallBackURL = client.Push_Call_Back;// "http://mpesa.ngrok.io/Deposit.svc/stkpush";
                        switch (d.Deposit_type)
                        {
                            case "Loan":
                                stkpush.AccountReference = d.Loan;
                                break;
                            default:
                                stkpush.AccountReference = d.Account_No;
                                break;
                        }
                        stkpush.TransactionDesc = "Ok";
                        var pushr = mpesa.Stkpush(stkpush);
                        if (pushr.success)
                        {
                            d.Mpesa_Status = (int)Status.Pending;
                            d.Conversation_ID = pushr.CheckoutRequestID;
                        }
                        else
                            d.Mpesa_Status = (int)Status.Failed;
                        db.SaveChanges();
                    }
                    catch (Exception ex)
                    {
                        Logging.Logging.ReportError(ex);
                    }
                }
            }
            //public void bulksms()
            //{
            //    int bal = Sms.Smsbalance(client.Client_Code);
            //    if (bal > 0)
            //    {
            //        S.SmsCompleted += new ClientService.SmsCompletedEventHandler(smsget);
            //        S.SmsAsync(bal);
            //        Waitforthis();
            //    }
            //}
            //private void Waitforthis()
            //{
            //    System.Threading.Thread.Sleep(60000);
            //}
            //void smsget(object sender, ClientService.SmsCompletedEventArgs e)
            //{
            //    int bal = Sms.Smsbalance(client.Client_Code);
            //    foreach (var item in e.Result)
            //    {
            //        Sms s = new Sms();
            //        var sourceid = db.BulkSms.FirstOrDefault(o=> o.Source_Id==item.Entry.ToString() && o.Client == client.Client_Code);
            //        if (sourceid == null)
            //        {
            //            s.Client = client.Client_Code;
            //            s.Message = item.Message;
            //            s.Source_Id = item.Entry.ToString();
            //            s.Balance = bal;
            //            s.Type = (int)Sms.Smstype.Bulk;
            //            s.Sendsms(s);
            //            item.SMS_Balance = bal;
            //            item.SMS_BalanceSpecified = true;
            //            bal = bal - 1;
            //        }
            //        else
            //        { 
            //            item.SMS_Balance =(int) sourceid.Balance;
            //            item.SMS_BalanceSpecified = true;
            //        }
            //        item.Delivered = true;
            //        item.DeliveredSpecified = true;
            //        item.Date_Delivered = DateTime.Now.Date;
            //        item.Date_DeliveredSpecified = true;
            //        item.Time_Delivered = DateTime.Now;
            //        item.Time_DeliveredSpecified = true;
            //    }

            //    S.Smsupdate(e.Result);
            //}
        }
    }
}
